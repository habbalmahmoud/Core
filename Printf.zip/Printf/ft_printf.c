/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/18 02:53:49 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/18 10:53:27 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdarg.h>
#include <stdio.h>
#include "printf.h"
#include <unistd.h>

void	ft_format(const char *inp, va_list args)
{
	int	i;

	i = 0;
	while (inp[i])
	{
		if (inp[i] == '%' && inp[i + 1] == 'c')
		{
			ft_putchar_fd(va_arg(args, int), 1);
			i += 2;
		}
		else if (inp[i] == '%' && inp[i + 1] == 's')
		{
			ft_putstr_fd(va_arg(args, char *), 1);
			i += 2;
		}
		else if (inp[i] == '%' && inp[i + 1] == 'p')
		{
			ft_putptr_fd(va_arg(args, char *), 1);
			i += 2;
		}
		else
			write (1, &inp[i++], 1);
	}
}

int	ft_printf(const char *inp, ...)
{
	va_list	args;

	va_start(args, inp);
	if (!inp)
		return (0);
	ft_format(inp, args);
	va_end(args);
	return (1);
}

int main(void)
{
	ft_printf("HI %s How are you! %s %c \n", "Boss", "my", 'g');
}
