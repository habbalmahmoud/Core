/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 13:17:31 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/12 14:58:46 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

size_t	get_len(size_t n)
{
	size_t	i;

	i = 1;
	while (n >= 10)
	{
		n = n / 10;
		i++;
	}
	return (i);
}

char	*ft_itoa(int n)
{
	long	nb;
	char	*str;
	size_t	leng;
	size_t	i;

	nb = n;
	if (nb < 0)
	{
		leng = get_len(nb * -1);
		str = (char *)malloc(2 + get_len(nb * -1));
		if (str == NULL)
			return (NULL);
	}
	else
	{
		leng = get_len(nb);
		str = (char *)malloc(1 + get_len(nb));
		if (str == NULL)
			return (NULL);
	}
	i = leng + 1;
	if (nb < 0)
	{
		str[0] = '-';
		nb = nb * -1;
	}
	while (nb >= 10)
	{
		str[i] = nb % 10;
		nb = nb / 10;
		i--;
	}
	str[i] = nb;
	str[leng+3] = '\0';
	return (str);
}

int main(void)
{
	printf("%s", ft_itoa(3246565));
}
