/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 11:00:06 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/12 11:20:14 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

size_t	is_found(char c, char const *set)
{
	size_t	i;

	i = 0;
	while (set[i])
	{
		if (set[i] == c)
			return (1);
		i++;
	}
	return (0);
}

size_t	get_spec_len(char const *s1, char const *set)
{
	size_t	i;
	size_t	j;

	j = 0;
	i = 0;
	while (s1[i])
	{
		if (!(is_found(s1[i], set)))
			j++;
		i++;
	}
	return (j);
}

char	*ft_strtrim(char const *s1, char const *set)
{
	size_t	strlen;
	char	*ptr;
	size_t	i;
	size_t	j;

	j = 0;
	i = 0;
	strlen = get_spec_len(s1, set);
	ptr = (char *)malloc(strlen + 1);
	if (ptr == NULL)
		return (NULL);
	while (s1[i])
	{
		if (!(is_found(s1[i], set)))
		{
			ptr[j] = s1[i];
			j++;
		}
		i++;
	}
	ptr[j] = '\0';
	return (ptr);
}
