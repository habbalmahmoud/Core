/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/13 09:29:34 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/13 09:51:27 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	unsigned int	i;
	int				j;
	char			*ptr;

	j = 0;
	i = 0;
	while (s[j])
	{
		if (f(j, s[j]))
			i++;
		j++;
	}
	ptr = (char *)malloc(i + 1);
	if (ptr == NULL)
		return (NULL);
	j = 0;
	i = 0;
	while (s[j])
	{
		if (f(j, s[j]))
			ptr[i++] = f(j, s[j]);
		j++;
	}
	ptr[i] = '\0';
	return (ptr);
}
