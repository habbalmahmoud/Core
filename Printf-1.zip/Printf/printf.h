/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   printf.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/18 02:57:55 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/19 12:59:46 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PRINTF_H
# define PRINTF_H

int		ft_printf(const char *inp, ...);
void	ft_putchar_fd(char c, int fd);
void	ft_putstr_fd(char *s, int fd);
void	ft_putptr_fd(long ptr, int fd);
void	handle_char(int c, int *i);
void	handle_strng(char *str, int *i);
void	handle_ptr(long ptr, int *i);
void	ft_putnbr_fd(int n, int fd);
void	handle_num(int num, int *i);
void	handle_num_u(unsigned int num, int *i);

#endif