/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/18 02:53:49 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/19 12:59:07 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdarg.h>
#include <stdio.h>
#include "printf.h"
#include <unistd.h>

void	ft_format(const char *inp, va_list args)
{
	int	i;

	i = 0;
	while (inp[i])
	{
		if (inp[i] == '%' && inp[i + 1] == 'c')
			handle_char(va_arg(args, int), &i);
		else if (inp[i] == '%' && inp[i + 1] == 's')
			handle_strng(va_arg(args, char *), &i);
		else if (inp[i] == '%' && inp[i + 1] == 'p')
			handle_ptr(va_arg(args, long), &i);
		else if (inp[i] == '%' && (inp[i + 1] == 'd' || inp[i + 1] == 'i'))
			handle_num(va_arg(args, int), &i);
		else if (inp[i] == '%' && inp[i + 1] == 'u')
			handle_num_u(va_arg(args, unsigned int), &i);
		else
			write (1, &inp[i++], 1);
	}
}

int	ft_printf(const char *inp, ...)
{
	va_list	args;

	va_start(args, inp);
	if (!inp)
		return (0);
	ft_format(inp, args);
	va_end(args);
	return (1);
}
int main(void)
{
	int i = 1;

	ft_printf("HI %s How are you! %s %c %p %i %u \n", "Boss", "my", 'g', &i, 45, -7808);
	printf("HI %s How are you! %s %c %p %i %u", "Boss", "my", 'g', &i, 45, -7808);
}
