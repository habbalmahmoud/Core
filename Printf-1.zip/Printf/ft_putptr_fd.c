/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putptr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/18 10:39:06 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/19 10:19:12 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "printf.h"
#include <unistd.h>

void	ft_putptr_fd(long ptr, int fd)
{
	char	*base;
	long	nb;

	nb = (long)ptr;
	base = "0123456789abcdef";
	if (nb >= 16)
	{
		ft_putptr_fd(nb / 16, fd);
		ft_putptr_fd(nb % 16, fd);
	}
	else
		ft_putchar_fd(base[nb], fd);
}

void	handle_ptr(long ptr, int *i)
{
	write (1, "0x", 2);
	ft_putptr_fd(ptr, 1);
	*i = *i + 2;
}
