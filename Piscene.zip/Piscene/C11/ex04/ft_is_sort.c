/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/09 15:32:54 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/10 16:06:16 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	is_asc(int *tab, int length, int (*f)(int, int))
{
	int	sort;
	int	i;

	sort = 1;
	i = 0;
	while (i < length - 1 && sort)
	{
		if (f(tab[i], tab[i + 1]) > 0)
		{
			sort--;
			break ;
		}
		i++;
	}
	return (sort);
}

int	is_desc(int *tab, int length, int (*f)(int, int))
{
	int	i;
	int	sort;

	i = 0;
	sort = 1;
	while (i < length - 1 && sort)
	{
		if (f(tab[i], tab[i + 1]) < 0)
		{
			sort--;
			break ;
		}
		i++;
	}
	return (sort);
}

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	if (is_desc(tab, length, f) == 1 || is_asc(tab, length, f) == 1)
		return (1);
	else
		return (0);
}

// int	compare(int i, int x)
// {
// 	if (i < x)
// 		return (-1);
// 	else if (i > x)
// 		return (1);
// 	else
// 		return (0);
// }

// int main(void)
// {
// 	int str[] = {1,5,3};
// 	printf("%d", ft_is_sort(str, 3, compare));
// }