/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/29 03:09:46 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/07 13:44:48 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	strslen(int size, char *str[])
{
	int	i;
	int	j;
	int	len;

	len = 0;
	i = 0;
	while (i < size)
	{
		j = 0;
		while (str[i][j] != '\0')
		{
			j++;
			len++;
		}
		i++;
	}
	return (len);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

void	add_sep(char *sep, char *ptr, int *m)
{
	int	j;

	j = 0;
	while (sep[j] != '\0')
	{
		*(ptr + *m) = sep[j];
		j++;
		*m = *m + 1;
	}
}

void	ft_concat(int size, char *ptr, char **strs, char *sep)
{
	int		i;
	int		j;
	int		m;

	m = 0;
	i = 0;
	while (i < size)
	{
		j = 0;
		while (strs[i][j] != '\0')
		{
			*(ptr + m) = strs[i][j];
			m++;
			j++;
		}
		if (i < size - 1)
		{
			add_sep(sep, ptr, &m);
		}
		i++;
	}
	*(ptr + m) = '\0';
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*ptr;
	int		len;
	int		f_size;

	f_size = ft_strlen(sep) * size - 1;
	len = strslen(size, strs);
	ptr = (char *)malloc((len + (f_size) + 1) * sizeof(char));
	if (ptr == NULL)
		return (NULL);
	if (size == 0)
	{
		ptr[0] = '\0';
		return (ptr);
	}
	ft_concat(size, ptr, strs, sep);
	return (ptr);
}

#include <stdio.h>

int main(void)
{
	char *strings[] = {
        "First string",
        "Second string",
        "Third string"
    };
	int size = 3;
	char *sep = "---";
	printf("%s", ft_strjoin(size, strings, sep));
}