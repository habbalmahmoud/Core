/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/29 00:10:00 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/30 13:20:09 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	ft_strlen(char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
		i++;
	return (i);
}

char	*ft_strdup(char *src)
{
	char	*ptr;
	int		j;

	j = 0;
	ptr = (char *)malloc((ft_strlen(src) + 1) * sizeof(char));
	if (ptr == NULL)
		return (NULL);
	while (src[j] != '\0')
	{
		*(ptr + j) = src[j];
		j++;
	}
	*(ptr + j) = '\0';
	return (ptr);
}

// int main(void)
// {
// 	char *str = "Hello World";
// 	printf("%s", ft_strdup(str));
// }