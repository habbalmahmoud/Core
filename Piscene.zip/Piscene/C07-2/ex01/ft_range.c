/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/29 00:34:20 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/30 12:33:14 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	*ft_range(int min, int max)
{
	int	*ptr;
	int	size;
	int	i;

	i = 0;
	if (min >= max)
	{
		return (NULL);
	}
	size = max - min;
	ptr = (int *)malloc(size * sizeof(int));
	if (ptr == NULL)
		return (NULL);
	while (min < max)
	{
		*(ptr + i) = min;
		i++;
		min++;
	}
	return (ptr);
}

// int main (void)
// {
// 	int min = 1;
// 	int max = 10;
// 	int *str = ft_range(min, max);
// 	while (*str != '\0')
// 	{
// 		printf("%d", *str);
// 		str++;
// 	}
// }