/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/27 04:52:31 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/09 11:12:45 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_strcmp(char *s1, char *s2)
{
	int	s1len;
	int	s2len;

	s1len = ft_strlen(s1);
	s2len = ft_strlen(s2);
	while (*s1 != '\0' && *s2 != '\0')
	{
		if (*s1 != *s2)
		{
			return (*s1 - *s2);
		}
		s1++;
		s2++;
	}
	if (s1len > s2len)
		return (*s1 - *s2);
	else
		return (*s1 - *s2);
	return (0);
}

void	scndloop(int j, int size, char *temp, char **str)
{
	while (j < size - 1)
	{
		if (ft_strcmp(str[j], str[j + 1]) > 0)
		{
			temp = str[j];
			str[j] = str[j + 1];
			str[j + 1] = temp;
		}
		j++;
	}
}

void	ft_sort_int_tab(char **str, int size)
{
	int		j;
	int		i;
	char	*temp;

	i = 0;
	temp = 0;
	while (i < size)
	{
		j = 0;
		scndloop(j, size, temp, str);
		i++;
	}
}

int	main(int argc, char *argv[])
{
	int	x;
	int	j;

	if (argc >= 2)
	{
		ft_sort_int_tab(argv, argc);
		x = 1;
		while (x < argc)
		{
			j = 0;
			while (argv[x][j])
			{
				write (1, &argv[x][j], 1);
				j++;
			}
			write (1, "\n", 1);
			x++;
		}
	}
}
