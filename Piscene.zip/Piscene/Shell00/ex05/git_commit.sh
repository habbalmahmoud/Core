#!/bin/bash

# Displaying last 5 commit IDs


# Run git log to retrieve last 5 commit IDs
git log -5 --format="%H" | while read commit_id; do
    echo "$commit_id"
done
