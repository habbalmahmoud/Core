/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/25 13:34:16 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/08 17:50:50 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	is_empty(char *base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
		i++;
	return (i);
}

int	is_found(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i] != '\0')
	{
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

int	is_numeric(char *base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == 43 || base[i] == 45)
			return (0);
		i++;
	}
	return (1);
}

void	pt_char(char C)
{
	write(1, &C, 1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		baselen;
	long	n;

	n = nbr;
	baselen = is_empty(base);
	if (baselen <= 1)
		return ;
	if (is_found(base) && is_numeric(base))
	{
		if (n < 0)
		{
			write (1, "-", 1);
			n = n * -1;
		}
		if (n >= baselen)
		{
			ft_putnbr_base(n / baselen, base);
			ft_putnbr_base(n % baselen, base);
		}
		if (n < baselen)
			pt_char(base[nbr]);
	}
}

// int main(void)
// {
// 	char *base = "poneyvif";
// 	int nbr = 42;
// 	ft_putnbr_base(nbr, base);
// }