/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/08 17:51:39 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/09 11:18:33 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_recursive_power(int nb, int power, int len)
{
	int	i;
	int num;

	num = 0;
	i = 0;
	while (i < power)
	{
		num = num + ()
	}
}

int	is_valid(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i] != '\0')
	{
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	j = 0;
	while (base[j] != '\0')
	{
		if (base[j] == 43 || base[j] == 45)
			return (0);
		j++;
	}
	return (j);
}

int	ft_atoi(char *str, int *power)
{
	int	i;
	int	prod;
	int	num;

	num = 0;
	prod = 1;
	i = 0;
	while ((str[i] >= 7 && str[i] <= 13) || str[i] == 32)
	{
		i++;
	}
	while (str[i] == 43 || str[i] == 45)
	{
		if (str[i] == 45)
			prod = prod * -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		num = num * 10 + (str[i] - '0');
		*power = *power + 1;
		i++;
	}
	return (num * prod);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_atoi_base(char *str, char *base)
{
	int	baselen;
	int	num;
	int	power;

	power = 0;
	baselen = is_valid(base);
	if (baselen <= 1)
		return (0);
	num = ft_atoi(str, &power);
	return (ft_recursive_power(num, power, baselen));
}

// int main(void)
// {
// 	ft_atoi_base("101010", "01");
// }