/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/23 19:01:26 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/24 10:30:34 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int				destlen;
	unsigned int	i;

	i = 0;
	destlen = 0;
	while (dest[destlen] != '\0')
	{
		destlen++;
	}
	while (src[i] != '\0' && i < nb)
	{
		dest[destlen + i] = src[i];
		i++;
	}
	dest[destlen + i] = '\0';
	return (dest);
}

// #include <stdio.h>
// #include <string.h>

// int main(void)
// {
// 	char dest[] = "Hello,";
// 	char src[] = " World!";

// 	printf("%s", ft_strncat(dest, src, 3));
// 	// printf("%s", strncat(dest, src, 3));
// }