/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/23 19:44:02 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/08 17:44:18 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned	int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	destlen;
	unsigned int	i;
	int				srclen;

	srclen = 0;
	i = 0;
	destlen = 0;
	while (dest[destlen] != '\0')
	{
		destlen++;
	}
	while (src[srclen] != '\0')
	{
		srclen++;
	}
	if (size == 0 || destlen >= size)
		return (size + srclen);
	while (src[i] != '\0' && i < size - destlen - 1)
	{
		dest[destlen + i] = src[i];
		i++;
	}
	dest[destlen + i] = '\0';
	return (destlen + srclen);
}

// #include <stdio.h>
// #include <string.h>

// int main(void) 
// {
// 	char dest[] = "Hello, ";
// 	char src[] = "World";

// 	ft_strlcat(dest, src , 4);
// 	// strlcat(dest, src, 3);
// 	printf("%s", dest);
// }