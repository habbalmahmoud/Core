/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 13:35:21 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/06 15:06:17 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_num(int k, int i, int j)
{
	char	m;
	char	c;
	char	s;

	s = ' ';
	c = ',';
	while (k < 10)
	{
		m = i + '0';
		write (1, &m, 1);
		m = j + '0';
		write (1, &m, 1);
		m = k + '0';
		write (1, &m, 1);
		if (i < 7)
		{
			write(1, &c, 1);
			write (1, &s, 1);
		}
		k++;
	}
}

void	ft_print_comb(void)
{
	int		i;
	int		j;
	int		k;

	i = 0;
	while (i < 8)
	{
		j = i + 1;
		while (j < 9)
		{
			k = j + 1;
			print_num(k, i, j);
			j++;
		}
		i++;
	}
}

// int main(void)
// {
// 	ft_print_comb();
// }