/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/20 01:44:27 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/20 03:33:54 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	scndloop(int j, int size, int temp, int *tab)
{
	while (j < size - 1)
	{
		if (tab[j] > tab[j + 1])
		{
			temp = tab[j];
			tab[j] = tab[j + 1];
			tab[j + 1] = temp;
		}
		j++;
	}
}

void	loopfunc(int i, int j, int size, int *tab)
{
	int	temp;

	temp = 0;
	while (i < size)
	{
		scndloop(j, size, temp, tab);
		i++;
	}
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	j;
	int	i;

	i = 0;
	j = 0;
	loopfunc(i, j, size, tab);
}
