/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 12:10:18 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/06 14:48:42 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
// #include <stdio.h>

int	search_sep(char C, char *sep)
{
	int	i;

	i = 0;
	while (sep[i])
	{
		if (sep[i] == C)
			return (1);
		i++;
	}
	return (0);
}

int	count_words(char *str, char *sep)
{
	int	words;
	int	i;

	words = 0;
	i = 0;
	while (str[i])
	{
		while (search_sep(str[i], sep))
			i++;
		if (!str[i])
			break ;
		while (!(search_sep(str[i], sep)))
		{
			if (!str[i])
				break ;
			i++;
		}
		words++;
	}
	return (words);
}

void	just_fill(int *i, char *strng, char *str, int j)
{
	int	m;

	m = 0;
	while (*i < j)
	{
		strng[m] = str[*i];
		m++;
		*i = *i + 1;
	}
	strng[m] = '\0';
}

void	search_fill(char *str, char *charset, char **strng, int *counter)
{
	int	i;
	int	j;

	i = 0;
	while (str[i])
	{
		while (search_sep(str[i], charset))
			i++;
		if (!str[i])
			break ;
		j = i;
		while (!(search_sep(str[j], charset)) && str[j])
			j++;
		strng[*counter] = (char *)malloc(((j - i) + 1) * sizeof(char));
		if (strng[*counter] == NULL)
			return ;
		just_fill(&i, strng[*counter], str, j);
		*counter = *counter + 1;
	}
}

char	**ft_split(char *str, char *charset)
{
	int		words;
	char	**strng;
	int		counter;

	counter = 0;
	words = count_words(str, charset);
	strng = (char **)malloc((words + 1) * sizeof(char *));
	if (strng == NULL)
		return (NULL);
	search_fill(str, charset, strng, &counter);
	strng[counter] = 0;
	return (strng);
}

// int main(void)
// {
// 	char **str = ft_split("ac1fJf6x0uKeF5zAeTtUFxPmDPu04kZXY", "0q9tYQ7");
// 	int words = count_words("ac1fJf6x0uKeF5zAeTtUFxPmDPu04kZXY", "0q9tYQ7");
// 	int i = 0;
// 	int x;
// 	while (i < words)
// 	{
// 		x = 0;
// 		while (str[i][x])
// 		{
// 			printf("%c",str[i][x]);
// 			x++;
// 		}
// 		printf("\n");
// 		i++;
// 	}
// }