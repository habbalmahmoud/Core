/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/20 15:41:55 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/23 12:18:10 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
// #include <unistd.h>

char	*ft_strcpy(char *dest, char *src)
{
	char	*originaldest;

	originaldest = dest;
	while (*src != '\0')
	{
		*dest = *src;
		src++;
		dest++;
	}
	*dest = '\0';
	return (originaldest);
}

// int main() {
//     // Test strings
//     char src[] = "Hello, world!";
//     char dest[50]; // Make sure dest has enough space 
// to hold the copied string

//     // Call ft_strcpy to copy src to dest
//     ft_strcpy(dest, src);

//     // Print the result
//     printf("Copied string: %s\n", dest);

//     return 0;
// }
