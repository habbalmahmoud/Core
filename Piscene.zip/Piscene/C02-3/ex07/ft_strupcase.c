/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 19:20:05 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/21 22:05:47 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

char	*ft_strupcase(char *str)
{
	char	*original;

	original = str;
	while (*str != '\0')
	{
		if (*str >= 'a' && *str <= 'z')
		{
			*str -= 32;
		}
		str++;
	}
	return (original);
}

// int	main(void)
// {
// 	char str3[] = "fowijfoiwj fdsfsf"; // all uppercase
//     printf("String 3 in uppercase: %s\n", ft_strupcase(str3));
//     return 0;
// }