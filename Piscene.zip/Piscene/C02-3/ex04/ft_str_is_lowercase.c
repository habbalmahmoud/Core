/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 18:27:39 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/21 18:39:03 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	while (*str != '\0')
	{
		if (*str < 97 || *str > 122)
		{
			return (0);
		}
		str++;
	}
	return (1);
}

// int main(void) {
// 	char *str = "abhsdd";
// 	char *pstr = "21dwfd";

// 	int on = ft_str_is_lowercase(str);
// 	int zer = ft_str_is_lowercase(pstr);

// 	printf("%d\n", on);
// 	printf("%d\n", zer);
// }