/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 19:03:54 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/21 23:21:58 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_str_is_printable(char *str)
{
	while (*str != '\0')
	{
		if (*str <= 31 || *str == 127)
		{
			return (0);
		}
		str++;
	}
	return (1);
}

// int main(void)
// {
	// int i = ft_str_is_printable("\t");
	// printf("%d", i);
// }