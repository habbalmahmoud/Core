/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 12:35:32 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/21 15:55:54 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	is_alph(char C)
{
	if ((C >= 'a' && C <= 'z') || (C >= 'A' && C <= 'Z'))
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int	ft_str_is_alpha(char *str)
{
	if (*str != '\0')
	{
		while (*str != '\0')
		{
			if (!is_alph(*str))
			{
				return (0);
			}
			str++;
		}
	}
	return (1);
}

// int main(void)
// {
// 	char	*str = "He0le";
// 	ft_str_is_alpha(str);
// }