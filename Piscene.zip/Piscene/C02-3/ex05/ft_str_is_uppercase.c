/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 18:40:03 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/21 18:44:09 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	while (*str != '\0')
	{
		if (*str < 65 || *str > 90)
		{
			return (0);
		}
		str++;
	}
	return (1);
}

// int main(void)
// {
// 	char *str = "HELLO";
// 	char *pstr = "helll";

// 	int on = ft_str_is_uppercase(str);
// 	int zer = ft_str_is_uppercase(pstr);

// 	printf("%d\n", on);
// 	printf("%d", zer);
// }