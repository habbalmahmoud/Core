/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 15:48:41 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/21 18:13:26 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
int	is_numeric(char C)
{
	if (C >= 48 && C <= 57)
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int	ft_str_is_numeric(char *str)
{
	if (*str != '\0')
	{
		while (*str != '\0')
		{
			if (!is_numeric(*str))
			{
				return (0);
			}
			str++;
		}
	}
	return (1);
}

// int main(void) {
// 	char *str = "01712";
// 	char *nstr = "963g34";

// 	int zer = ft_str_is_numeric(nstr);
// 	int on = ft_str_is_numeric(str);

// 	printf("%d\n", zer);
// 	printf("%d", on);
// }