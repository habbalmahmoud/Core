/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:06:49 by mhabbal           #+#    #+#             */
/*   Updated: 2024/05/07 10:33:46 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	pt_char(char C)
{
	write(1, &C, 1);
}

void	ft_putstr_non_printable(char *str)
{
	int		i;
	char	c;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 32 && str[i] < 127)
		{
			write(1, &str[i], 1);
		}
		else
		{
			c = str[i];
			pt_char('\\');
			pt_char("0123456789abcdef"[c / 16]);
			pt_char("0123456789abcdef"[c % 16]);
		}
		i++;
	}
}

// int main(void)
// {
// 	ft_putstr_non_printable("Coucou\ntu vas bien ?");
// }