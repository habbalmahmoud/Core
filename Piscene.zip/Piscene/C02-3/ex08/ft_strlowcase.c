/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 20:56:48 by mhabbal           #+#    #+#             */
/*   Updated: 2024/04/21 22:56:08 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

char	*ft_strlowcase(char *str)
{
	char	*original;

	original = str;
	while (*str != '\0')
	{
		if (*str >= 'A' && *str <= 'Z')
		{
			*str += 32;
		}
		str++;
	}
	return (original);
}

// int main() {
//     char str3[] = "JKBBW HWIJBVI``"; // all lowercase
//     printf("String 3 in lowercase: %s\n", ft_strlowcase(str3));

//     return 0;
// }