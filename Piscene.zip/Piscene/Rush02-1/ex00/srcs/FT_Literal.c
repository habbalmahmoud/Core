/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FT_Literal.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 21:07:08 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 23:22:13 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

void	ft_print(char *str, int *first)
{
	if (*first != 0)
	{
		ft_putchar(' ');
	}
	*first = 1;
	ft_putstr(str);
}

int	ft_print_zero(t_dict *start)
{
	ft_putstr(start->value);
	ft_putchar('\n');
	return (0);
}

void	to_print(int *i, t_dict *start, char *t_input, int *first)
{
	int	postion;

	postion = ft_strlen(t_input) - *i - 1;
	if (postion % 3 == 1 && t_input[*i] == '1')
	{
		ft_print(get_lit2(start, t_input[*i], t_input[*i + 1]), first);
		(*i)++;
	}
	else if (postion % 3 == 1 && t_input[*i] != '1' && t_input[*i] != '0')
		ft_print(get_lit_tenth(start, 2, t_input[*i]), first);
	else if (postion % 3 == 0 && t_input[*i] != '0')
		ft_print(get_lit(start, t_input[*i]), first);
	else if (postion % 3 == 2 && t_input[*i] != '0')
	{
		ft_print(get_lit(start, t_input[*i]), first);
		ft_print(get_lit_by_len(start, 3), first);
	}
	postion = ft_strlen(t_input) - *i - 1;
	if (postion % 3 == 0 && postion != 0)
	{
		if (t_input[*i - 1] != '0' || t_input[*i - 2] != '0'
			|| t_input[*i] != '0')
			ft_print(get_lit_by_len(start, postion + 1), first);
	}
}

int	solution(char *t_input, t_dict *start)
{
	int		i;
	int		first;

	first = 0;
	i = 0;
	while (t_input[i] != '\0')
	{
		to_print(&i, start, t_input, &first);
		i++;
	}
	ft_putchar('\n');
	return (1);
}
