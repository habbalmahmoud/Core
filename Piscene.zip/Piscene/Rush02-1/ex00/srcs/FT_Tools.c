/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FT_Tools.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 21:06:40 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 23:24:53 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	ft_strcmp(char *s1, char *s2)
{
	unsigned int	i;

	if (ft_strlen(s1) > ft_strlen(s2))
		return (1);
	if (ft_strlen(s1) < ft_strlen(s2))
		return (-1);
	i = 0;
	while (s1[i] == s2[i] && s1[i] != '\0')
	{
		i++;
	}
	if (s1[i] == s2[i])
	{
		return (0);
	}
	else
	{
		return (s1[i] - s2[i]);
	}
}

int	check_longest(char *terminal_input, t_dict *initial)
{
	int		t_input_len;
	int		longest_dict;
	t_dict	*current;

	current = initial;
	t_input_len = ft_strlen(terminal_input);
	while (current != NULL)
	{
		longest_dict = ft_strlen(current->numb);
		current = current->next;
	}
	if (t_input_len > longest_dict + 2)
		return (0);
	return (1);
}

t_dict	*make_node(char *numb, char *value)
{
	t_dict	*node;

	node = (t_dict *)malloc(sizeof(t_dict));
	if (!node)
		return (0);
	node->numb = numb;
	node->value = value;
	node->next = NULL;
	return (node);
}

void	free_linked_list(t_dict *start)
{
	t_dict	*current;
	t_dict	*temporary;

	current = start;
	while (current != NULL)
	{
		temporary = current;
		current = current->next;
		free(temporary->numb);
		free(temporary->value);
		free(temporary);
	}
}
