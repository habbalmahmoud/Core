/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FT_ParseInLine.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 21:03:28 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 23:15:58 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

char	*get_number(char	*str)
{
	int		i;
	char	*key;

	i = 0;
	while (str[i] >= '0' && str[i] <= '9' && str[i] != ':')
		i++;
	key = (char *)malloc(sizeof(char) * (i + 1));
	if (!key)
		return (NULL);
	i = 0;
	while (str[i] >= '0' && str[i] <= '9' && str[i] != ':')
	{
		key[i] = str[i];
		i++;
	}
	key[i] = '\0';
	return (key);
}

char	*get_value(char *str, int colon)
{
	int		i;
	int		j;
	char	*value;

	i = colon + 1;
	while (str[i] == ' ')
		i++;
	j = 0;
	while (str[i++] != '\0')
		j++;
	value = (char *)malloc(sizeof(char) * (j + 1));
	if (!value)
		return (NULL);
	i = colon + 1;
	j = 0;
	while (str[i] == ' ')
		i++;
	while (str[i] != '\0')
		value[j++] = str[i++];
	value[j] = '\0';
	return (value);
}

int	check_colon(char *str)
{
	int	i;
	int	pos;

	i = 0;
	pos = -1;
	while (str[i] != '\0')
	{
		if (str[i] == ':' && pos == -1)
			pos = i;
		i++;
	}
	if (pos == -1 || pos == i - 1 || pos == 0)
		return (-1);
	return (pos);
}

void	key_value_to_dict(char *key, char *value, t_dict *initial)
{
	t_dict	*new_node;
	t_dict	*current;

	if (initial->numb == NULL)
	{
		initial->numb = key;
		initial->value = value;
	}
	else
	{
		new_node = make_node(key, value);
		current = initial;
		while (current->next != NULL
			&& ft_strcmp(new_node->numb, current->next->numb) > 0)
		{
			current = current->next;
		}
		new_node->next = current->next;
		current->next = new_node;
	}
}

int	process_add_to_dict(char *str, t_dict *initial)
{
	char	*key;
	char	*value;
	int		colon;

	colon = check_colon(str);
	if (colon == -1)
		return (0);
	key = get_number(str);
	value = get_value(str, colon);
	if (!key || !value)
		return (0);
	key_value_to_dict(key, value, initial);
	return (1);
}
