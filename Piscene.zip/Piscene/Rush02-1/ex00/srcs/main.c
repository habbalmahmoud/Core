/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 21:06:18 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 23:24:10 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

int	onlyzeros(char *terminal_input)
{
	int	i;

	i = 0;
	while (terminal_input[i] != '\0')
	{
		if (terminal_input[i] != '0')
			return (0);
		i++;
	}
	return (1);
}

int	main(int argc, char *argv[])
{
	char	*dict_name;
	char	*terminal_input;
	t_dict	*intitial;
	int		file;

	intitial = NULL;
	if (ft_check_args(&dict_name, &terminal_input, argc, argv) == 0)
		return (ft_error(1));
	file = open(dict_name, O_RDWR);
	if (file == -1)
		return (ft_error(2));
	intitial = make_node(NULL, NULL);
	if (parse_file_to_dict(dict_name, intitial) == 0)
		return (ft_error(2));
	if (onlyzeros(terminal_input) == 1)
	{
		return (ft_print_zero(intitial));
	}
	while (*terminal_input == '0')
		terminal_input++;
	if (check_longest(terminal_input, intitial) == 0
		|| solution(terminal_input, intitial) == 0)
		return (ft_error(2));
	free_linked_list(intitial);
	return (0);
}
