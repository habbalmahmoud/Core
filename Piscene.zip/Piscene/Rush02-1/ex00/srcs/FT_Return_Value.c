/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FT_Return_Value.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 21:06:48 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 23:10:31 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

char	*get_lit(t_dict *initial, char c)
{
	t_dict	*current;

	current = initial;
	while (current != NULL && ft_strlen(current->numb) < 2)
	{
		if (c == (current->numb)[0])
		{
			return (current->value);
		}
		current = current->next;
	}
	return (NULL);
}

char	*get_lit2(t_dict *initial, char c1, char c2)
{
	t_dict	*current;

	current = initial;
	while (current != NULL && ft_strlen(current->numb) < 3)
	{
		if (ft_strlen(current->numb) == 2
			&& c1 == (current->numb)[0] && c2 == (current->numb)[1])
		{
			return (current->value);
		}
		current = current->next;
	}
	return (NULL);
}

char	*get_lit_by_len(t_dict *initial, int length)
{
	t_dict	*current;

	current = initial;
	while (current != NULL && ft_strlen(current->numb) <= length)
	{
		if (ft_strlen(current->numb) == length)
		{
			return (current->value);
		}
		current = current->next;
	}
	return (NULL);
}

char	*get_lit_tenth(t_dict *initial, int length, char c)
{
	t_dict	*current;

	current = initial;
	while (current != NULL && ft_strlen(current->numb) <= length)
	{
		if (ft_strlen(current->numb) == length && current->numb[0] == c)
		{
			return (current->value);
		}
		current = current->next;
	}
	return (NULL);
}
