/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Argument_Check.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 21:01:28 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 23:25:44 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

int	ft_check_args(char **file_name, char **t_input, int argc, char **argv)
{
	if (argc == 2)
	{
		*file_name = "files/numbers.dict";
		if (!ft_is_numeric(argv[1]))
			return (0);
		*t_input = argv[1];
		return (1);
	}
	if (argc == 3)
	{
		*file_name = argv[1];
		if (!ft_is_numeric(argv[2]))
			return (0);
		*t_input = argv[2];
		return (1);
	}
	return (0);
}

int	ft_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= '0' && str[i] <= '9'))
			return (0);
		i++;
	}
	return (1);
}

int	ft_error(int type)
{
	if (type == 1)
		ft_putstr("Error\n");
	if (type == 2)
		ft_putstr("DictError\n");
	return (0);
}
