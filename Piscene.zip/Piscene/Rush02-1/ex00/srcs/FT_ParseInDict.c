/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FT_ParseInDict.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 21:02:25 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 21:03:10 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

int		process_add_to_dict(char *str, t_dict *start);

char	*add_character(char *str, char c)
{
	char	*str2;
	int		i;

	i = 0;
	str2 = (char *)malloc(sizeof(char) *(ft_strlen(str) + 2));
	if (!str2)
		return (NULL);
	while (str[i] != '\0')
	{
		str2[i] = str[i];
		i++;
	}
	free(str);
	str2[i] = c;
	i++;
	str2[i] = '\0';
	return (str2);
}

char	*read_line(int file)
{
	char	buf[1];
	int		size;
	char	*str;

	str = (char *)malloc(sizeof(char));
	if (!str)
		return (NULL);
	str[0] = '\0';
	size = read(file, buf, 1);
	while (size != 0 && buf[0] != '\n')
	{
		str = add_character(str, buf[0]);
		if (!str)
			return (NULL);
		size = read(file, buf, 1);
	}
	if (size == 0 && str[0] == '\0')
	{
		free(str);
		return (NULL);
	}
	return (str);
}

int	process_lines(char *line, t_dict *start)
{
	if (line != NULL && ft_strlen(line) != 0)
	{
		if (!process_add_to_dict(line, start))
		{
			free(line);
			return (0);
		}
	}
	free(line);
	return (1);
}

int	read_file_and_process_lines(int file, t_dict *start)
{
	char	*line;

	line = read_line(file);
	while (line != NULL)
	{
		if (!process_lines(line, start))
		{
			close(file);
			return (0);
		}
		line = read_line(file);
	}
	close(file);
	return (1);
}

int	parse_file_to_dict(char *filename, t_dict *start)
{
	int	file;

	file = open(filename, O_RDWR);
	if (file != -1)
	{
		if (!read_file_and_process_lines(file, start))
		{
			close(file);
			return (0);
		}
		close(file);
	}
	return (1);
}
