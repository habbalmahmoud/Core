/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aramadan <aramadan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 22:27:01 by aramadan          #+#    #+#             */
/*   Updated: 2024/05/05 23:27:08 by aramadan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

# include <fcntl.h>
# include <stdlib.h>
# include <unistd.h>
# include <string.h>

typedef struct s_dict
{
	char			*numb;
	char			*value;
	struct s_dict	*next;

}	t_dict;

t_dict	*make_node(char *nb, char *lit);
int		ft_is_numeric(char *str);
void	ft_putchar(char c);
void	ft_putstr(char *str);
int		ft_strlen(char *str);
void	ft_putnbr(int nb);
int		ft_strcmp(char *s1, char *s2);
int		check_colon(char *str);
char	*add_character(char *str, char c);
char	*get_number(char *str);
char	*get_value(char *str, int colon);
int		ft_check_args(char **file_name,
			char **t_input, int argc, char **argv);
char	*ft_strcpy(char *dest, char *src);
int		parse_file_to_dict(char *filename, t_dict *start);
int		solution(char *t_input, t_dict *start);
int		check_longest(char *input_name, t_dict *start);
int		ft_error(int type);
char	*get_lit(t_dict *start, char c);
char	*get_lit2(t_dict *start, char c1, char c2);
char	*get_lit_by_len(t_dict *start, int len);
char	*get_lit_tenth(t_dict *start, int len, char c);
int		ft_print_zero(t_dict *start);
void	free_linked_list(t_dict *start);

#endif
