/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/22 09:31:19 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/22 12:06:09 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "get_next_line.h"

char	*get_next_line(int fd)
{
	static char	*buffer;
	char		*line;
	size_t		bytes_read;
	int			i;

	i = 0;
	if (!fd)
		return (NULL);
	buffer = (char *)malloc(BUFFER_SIZE);
	if (!buffer)
		return (NULL);
	bytes_read = read(fd, buffer, BUFFER_SIZE);
	if (bytes_read == -1)
		return (NULL);
	while (bytes_read > 0 && i < BUFFER_SIZE)
	{
		if (buffer[i] == '\n')
		{
			line = add_char(line, buffer[i]);
			buffer += i;
			break ;
		}
		if (!buffer[i])
			break ;
		line = add_char(line, buffer[i]);
	}
}
