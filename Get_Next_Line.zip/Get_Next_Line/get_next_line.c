/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/22 09:31:19 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/24 13:15:45 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include "get_next_line.h"
#include <stdio.h>

#ifndef BUFFER_SIZE
# define BUFFER_SIZE 42
#endif

// void	get_full_line(char *line, char *buffer, size_t bytes_read)
// {
// 	int		i;

// 	i = 0;
// 	while (bytes_read > 0 && i < BUFFER_SIZE)
// 	{
// 		if (*buffer == '\n')
// 		{
// 			line = add_char(line, *buffer);
// 			buffer++;
// 			break ;
// 		}
// 		if (!buffer)
// 			break ;
// 		line = add_char(line, *buffer);
// 		buffer++;
// 		i++;
// 	}
// 	if (i == BUFFER_SIZE)
// 		get_full_line(line, buffer, bytes_read);
// }

// char	*handle_line(char *buffer, size_t bytes_read)
// {
// 	int		i;
// 	char	*line;

// 	line = (char *)malloc(1);
// 	i = 0;
// 	while (bytes_read > 0 && i < BUFFER_SIZE)
// 	{
// 		if (*buffer == '\n')
// 		{
// 			line = add_char(line, *buffer);
// 			buffer++;
// 			break ;
// 		}
// 		if (!buffer)
// 			break ;
// 		line = add_char(line, *buffer);
// 		buffer++;
// 		i++;
// 		if (i == BUFFER_SIZE)
// 			get_full_line(line, buffer, bytes_read);
// 	}
// 	return (line);
// }

char	*get_next_line(int fd)
{
	char			*buffer;
	static char		*s_line;
	int				bytes_read;
	char			*line;

	if (!fd || BUFFER_SIZE < 0)
		return (NULL);
	buffer = (char *)malloc (BUFFER_SIZE);
	if (!buffer)
		return (buffer);
	bytes_read = read(fd, buffer, BUFFER_SIZE);
	s_line = malloc(1);
	if (!s_line)
		return (NULL);
	while (bytes_read > 0)
	{
		s_line = ft_strjoin(s_line, buffer);
		bytes_read = read(fd, buffer, BUFFER_SIZE);
	}
	line = malloc(1);
	int i = 0;
	while (s_line[i] != '\n')
	{
		line = add_char(line, *s_line);
		s_line++;
		i++;
	}
	return (s_line);
}

int main(void)
{
	int fd = open("test1.txt", O_RDONLY);
	char *line = get_next_line(fd);
	printf("%s", line);
	free(line);
}
