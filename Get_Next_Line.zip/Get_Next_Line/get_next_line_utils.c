/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhabbal <mhabbal@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/22 09:42:52 by mhabbal           #+#    #+#             */
/*   Updated: 2024/06/22 11:51:06 by mhabbal          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*add_char(char *line, char c)
{
	int		len;
	char	*new_line;

	len = ft_strlen(line);
	new_line = (char *)malloc(len + 2);
	new_line[len] = c;
	new_line[len + 1] = '\0';
	return (new_line);
}
